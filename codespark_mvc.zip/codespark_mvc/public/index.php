<?php
    require_once '../app/bootstrap.php';

    // Init Core Library

    $init = new Core;